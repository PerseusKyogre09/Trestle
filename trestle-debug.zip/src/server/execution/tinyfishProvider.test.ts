import { afterEach, describe, expect, it } from "vitest";
import { TinyFishExecutionProvider, parseSseBlock } from "./tinyfishProvider";
import type { ExecutionContext } from "./types";

const context: ExecutionContext = {
  caseId: "case-1",
  actionId: "identify-reporting",
  operation: {
    operationType: "lost_document_research",
    description: "Research official replacement guidance.",
    payload: {
      jurisdiction: "United Kingdom",
      documentType: "driving licence",
    },
  },
};

function responseFor(events: string[]): Response {
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      for (const event of events) {
        controller.enqueue(new TextEncoder().encode(event));
      }
      controller.close();
    },
  });
  return new Response(stream, { status: 200 });
}

describe("TinyFishExecutionProvider", () => {
  afterEach(() => {
    delete process.env.TINYFISH_API_KEY;
  });

  it("parses multiple events and accepts only a completed final event", async () => {
    process.env.TINYFISH_API_KEY = "test-key";
    const provider = new TinyFishExecutionProvider(async () =>
      responseFor([
        'data: {"type":"STARTED","run_id":"run-1"}\n\n',
        'data: {"type":"PROGRESS","purpose":"Searching"}\n\n',
        'data: {"type":"COMPLETE","status":"COMPLETED","result":{"summary":"Found guidance","sourceUrls":["https://gov.example"]}}\n\n',
      ])
    );

    const result = await provider.execute(context);

    expect(result.status).toBe("succeeded");
    expect(result.isSimulated).toBe(false);
    expect(result.canVerifyOutcome).toBe(false);
    expect(result.details?.sourceUrls).toEqual(["https://gov.example"]);
    expect((result.details?.trace as Array<Record<string, unknown>>).map((event) => event.type)).toEqual([
      "STARTED",
      "PROGRESS",
      "COMPLETE",
    ]);
  });

  it("returns after COMPLETE even when TinyFish keeps the SSE connection open", async () => {
    process.env.TINYFISH_API_KEY = "test-key";
    const provider = new TinyFishExecutionProvider(async () => {
      const stream = new ReadableStream<Uint8Array>({
        start(controller) {
          controller.enqueue(new TextEncoder().encode(
            'data: {"type":"COMPLETE","status":"COMPLETED","result":{"summary":"Finished"}}\n\n',
          ));
        },
      });
      return new Response(stream, { status: 200 });
    }, 5000);

    const result = await provider.execute(context);

    expect(result.status).toBe("succeeded");
    expect(result.resultSummary).toBe("Finished");
  });

  it("recognizes the SSE event name when the payload omits its type", async () => {
    process.env.TINYFISH_API_KEY = "test-key";
    const provider = new TinyFishExecutionProvider(async () =>
      responseFor([
        'event: COMPLETE\ndata: {"status":"COMPLETED","result":{"summary":"Finished"}}\n\n',
      ])
    );

    const result = await provider.execute(context);

    expect(result.status).toBe("succeeded");
    expect(result.resultSummary).toBe("Finished");
  });

  it("handles incomplete chunks and failed terminal events", async () => {
    process.env.TINYFISH_API_KEY = "test-key";
    const provider = new TinyFishExecutionProvider(async () =>
      responseFor([
        'data: {"type":"STARTED"}\n',
        '\ndata: {"type":"COMPLETE","status":"FAILED","error":{"help_message":"Run failed"}}\n\n',
      ])
    );

    const result = await provider.execute(context);

    expect(result.status).toBe("failed");
    expect(result.resultSummary).toContain("Run failed");
  });

  it("reports malformed stream data as inconclusive", async () => {
    process.env.TINYFISH_API_KEY = "test-key";
    const provider = new TinyFishExecutionProvider(async () =>
      responseFor(['data: {not-json}\n\n'])
    );

    const result = await provider.execute(context);

    expect(result.status).toBe("uncertain");
    expect(result.uncertaintyReason).toContain("malformed");
  });

  it("reports a timeout as inconclusive", async () => {
    process.env.TINYFISH_API_KEY = "test-key";
    const provider = new TinyFishExecutionProvider(
      (_input, init) => new Promise((_resolve, reject) => {
        init?.signal?.addEventListener("abort", () => {
          const error = new Error("aborted");
          error.name = "AbortError";
          reject(error);
        });
      }),
      1,
    );

    const result = await provider.execute(context);

    expect(result.status).toBe("uncertain");
    expect(result.uncertaintyReason).toContain("timed out");
  });

  it("does not allow the live provider without a key", async () => {
    const provider = new TinyFishExecutionProvider();
    const eligibility = await provider.checkEligibility(context);

    expect(eligibility.eligible).toBe(false);
    expect(eligibility.reason).toContain("TINYFISH_API_KEY");
  });

  it("rejects unsupported operations", async () => {
    process.env.TINYFISH_API_KEY = "test-key";
    const provider = new TinyFishExecutionProvider();
    const eligibility = await provider.checkEligibility({
      ...context,
      operation: { ...context.operation, operationType: "pay_fee" },
    });

    expect(eligibility.eligible).toBe(false);
    expect(eligibility.supportsOperation).toBe(false);
  });

  it("rejects private research values before making an outbound request", async () => {
    process.env.TINYFISH_API_KEY = "test-key";
    let called = false;
    const provider = new TinyFishExecutionProvider(async () => {
      called = true;
      return responseFor([]);
    });

    await expect(provider.execute({
      ...context,
      operation: {
        ...context.operation,
        payload: {
          jurisdiction: "India",
          documentType: "Aadhaar number 123456789012",
        },
      },
    })).rejects.toThrow(/generic, non-personal/);
    expect(called).toBe(false);
  });

  it("rejects malformed SSE JSON directly", () => {
    expect(() => parseSseBlock("data: nope")).toThrow();
  });
});
